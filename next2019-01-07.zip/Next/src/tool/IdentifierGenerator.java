package tool;

public class IdentifierGenerator {
	
	// 对用户的编号
	public static String HumanIdentifier() {
		return "000" + Time.CurrentTime();
	}
	
	// 对物品的编号
	public static String StuffIdentifier() {
		return "010" + Time.CurrentTime();
	}
	
	// 对购物车的编号
	public static String CartsIdentifier() {
		return "020" + Time.CurrentTime();
	}
	
	// 对好友的编号
	public static String FriendsIdentifier() {
		return "030" + Time.CurrentTime();
	}
	
	// 对赠礼的编号
	public static String ExchangeIdentifier() {
		return "040" + Time.CurrentTime();
	}
	
	// 对类型的编号
	public static String TypeIdentifier() {
		return "050" + Time.CurrentTime();
	}
	
	// 对留言的编号
	public static String MessageIdentifier() {
		return "060" + Time.CurrentTime();
	}
	
//	public static void main(String[] args) {
//		tip.showTip(HumanIdentifier());
//	}
}
