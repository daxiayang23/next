package tool;

public class tip {
	public static void showTip(String x) {
		System.out.println(x);
	}
}
