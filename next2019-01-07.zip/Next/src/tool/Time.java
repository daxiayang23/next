package tool;

import java.util.Calendar;

public class Time {
	private static Calendar now = Calendar.getInstance();
	
	//当前日期， 年
	public static int Year() {
		return now.get(Calendar.YEAR);
	}
	
	//当前日期， 月
	public static int Month() {
		return now.get(Calendar.MONTH) + 1;
	}
	
	//当前日期， 日
	public static int Day() {
		return now.get(Calendar.DATE);
	}
	
	//当前日期， 时
	public static int Hour() {
		return now.get(Calendar.HOUR_OF_DAY);
	}
	
	//当前日期， 分
	public static int Minute() {
		return now.get(Calendar.MINUTE);
	}
	
	//当前日期，秒
	public static int Second() {
		return now.get(Calendar.SECOND);
	}
	
	//当前日期，毫秒
	public static int MilliSecond() {
		return now.get(Calendar.MILLISECOND);
	}
	
	public static String CurrentTime() {
		String Month = "0" + Month();
		String Day = "0" + Day();
		String Hour = "0" + Hour();
		String Minute = "0" + Minute();
		String Second = "0" + Second();
		String MilliSecond = "00" + MilliSecond();
		if(Month() >= 10)
			Month = Month.substring(1);
		if(Day() >= 10) 
			Day = Day.substring(1);
		if(Hour() >= 10)
			Hour = Hour.substring(1);
		if(Minute() >= 10)
			Minute = Minute.substring(1);
		if(Second() >= 10)
			Second = Second.substring(1);
		if(MilliSecond() >= 100)
			MilliSecond = MilliSecond.substring(2);
		else if(MilliSecond() >= 10) 
			MilliSecond = MilliSecond.substring(1);
		return Year() + Month + Day + Hour + Minute + Second + MilliSecond;
	}
}
