package tool;

public class tool {
	public static String convertToChinese(String str) {
		if(str!=null) {
			try {
				String tempStr = str;
				byte[] tempBytes = tempStr.getBytes("ISO-8859-1");
				tempStr = new String(tempBytes,"utf-8");
				return tempStr;
			} catch(Exception e) {
				e.printStackTrace();
				return "";
			}
		} else 
			return "";
	}
}