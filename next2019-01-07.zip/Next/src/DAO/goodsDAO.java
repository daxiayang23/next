package DAO;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import bean.goodsBean;


public class goodsDAO {
	
	
	
	
	
	
	
	
	/*
	 *  添加商品，
	 *  addGoods方法，传参(goodsBean)gb，返回值(int)mark
	 */
	
	
	public static int addGoods(goodsBean gb) {
		
		int mark = 0;
		
		String sql = // SQL语句
		"insert into goods (gnumber,gname,creator,gsum,price) values ('" +
		gb.getgNumber()+"','" + 
		gb.getgName() + "','" + 
		gb.getCreator() + "'," + 
		gb.getgSum() + "," + 
		gb.getPrice() + ")";
	
		baseDAO db = new baseDAO();
		
		db.getConnection();
		
		db.createStatement();
		
		mark = db.executeUpdate(sql);
		
		return mark;
	
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	/*
	 *  检查商品，
	 *  checkGoods方法，传参(goodsBean)gb、(int)i, 返回值类型(goodsBean)
	 *  返回值goodsBean类型
	 */
	
	
	public static goodsBean checkGoods(goodsBean gb) {
		
		goodsBean g = new goodsBean();
		
		String sql = "select gnumber,gname,gstatus,creator,gsum,price,gift from goods where creator='" + gb.getCreator() + "' and gnumber='"+ gb.getgNumber() +"'";
		
		baseDAO db = new baseDAO();
		
		db.getConnection();
		
		db.createStatement();
		
		ResultSet rs = db.executeQuery(sql);
		
		try {
	
			if(rs.next()) {

				g.setgNumber(rs.getString(1));
				
				g.setgName(rs.getString(2));
				
				g.setgStatus(rs.getInt(3));
				
				g.setCreator(rs.getString(4));
				
				g.setgSum(rs.getInt(5));
				
				g.setPrice(rs.getInt(6));
				
				g.setGift(rs.getBoolean(7));
		
			}
	
		} catch (SQLException e) {
			
			e.printStackTrace();
		
		} finally {
		
			db.close();
		
		}
		
		return gb;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	/*
	 *  获取商品列表，所发布的所有商品
	 *  传参(String)stu学号，(int)PageStart页面开始，(int)PageEnd页面结束
	 *  返回值ArrayList<goodsBean>类型
	 */
	
	public static ArrayList<goodsBean> goodsList(int PageStart, int PageEnd) {// 获取所有商品或者动态
		
		ArrayList<goodsBean> list = new ArrayList<goodsBean>();
		
		goodsBean gb = new goodsBean();
		
		int count = 0;
		
		String sql = "select gnumber,gname,gstatus,creator,gsum,price,gift from goods";
		
		baseDAO db = new baseDAO();
		
		db.getConnection();
		
		db.createStatement();
		
		ResultSet rs = db.executeQuery(sql);
		
		try {
		
			while(rs.next()) {
			
				if(count > PageStart) continue;
				
				if(count < PageEnd) break;
				
				gb.setgNumber(rs.getString(1));
				
				gb.setgName(rs.getString(2));
				
				gb.setgStatus(rs.getInt(3));
				
				gb.setCreator(rs.getString(4));
				
				gb.setgSum(rs.getInt(5));
				
				gb.setPrice(rs.getInt(6));
				
				gb.setGift(rs.getBoolean(7));
				
				list.add(gb);
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
	
		} finally {

			db.close();
	
		}
		
		return list;

	}

	
	
	
	
	public static ArrayList<goodsBean> goodsList(String stu, int PageStart, int PageEnd) { // 获取某个同学所发布的全部商品或者动态
		
		ArrayList<goodsBean> list = new ArrayList<goodsBean>();
		
		goodsBean gb = new goodsBean();
		
		int count = 0;
		
		String sql = "select gnumber,gname,gstatus,creator,gsum,price,gift from goods where creator='" + stu + "'";
		
		baseDAO db = new baseDAO();
		
		db.getConnection();
		
		db.createStatement();
		
		ResultSet rs = db.executeQuery(sql);
		
		try {
		
			while(rs.next()) {
			
				if(count > PageStart) continue;
				
				if(count < PageEnd) break;
				
				gb.setgNumber(rs.getString(1));
				
				gb.setgName(rs.getString(2));
				
				gb.setgStatus(rs.getInt(3));
				
				gb.setCreator(rs.getString(4));
				
				gb.setgSum(rs.getInt(5));
				
				gb.setPrice(rs.getInt(6));
				
				gb.setGift(rs.getBoolean(7));
				
				list.add(gb);
			}
			
		} catch (SQLException e) {
	
			e.printStackTrace();
	
		} finally {

			db.close();
	
		}
		
		return list;

	}
	

	
	
	
	
	
	
	
}
