package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class baseDAO {
	
	private Connection conn = null;
	private Statement stmt = null;
	private PreparedStatement psmt = null;
	private ResultSet rs = null;
	
	
	
	/*
	 *   加载驱动
	 */
	public baseDAO() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("*");
		} catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	
	
	/*
	 *   创建连接
	 */
	public Connection getConnection() {
		String constr = "jdbc:mysql://localhost:3306/next";
		String conuser = "root";
		String conpass = "";	//记得更改密码。。。
		try {
			conn = DriverManager.getConnection(constr, conuser, conpass);
			if(conn != null)
				System.out.print("   ");
			else
				System.out.println("数据库连接失败");
		} catch(SQLException sqle) {
			sqle.printStackTrace();
		} 
		return conn;
	}
	
	
	
	/*
	 *   创建语句对象
	 */
	public Statement createStatement() {
		try {
			stmt = conn.createStatement();
			if(stmt != null)
				System.out.print("   ");
			else 
				System.out.println("警告：语句对象创建失败！！！");
		} catch(SQLException sqle) {
			sqle.printStackTrace();
		}
		return stmt;
	}
	
	
	
	
	/*
	 *   创建预处理语句对象
	 */
	public PreparedStatement prepareStatement(String sql) {
		try {
			psmt = conn.prepareStatement(sql);
		} catch(SQLException e) {
			e.printStackTrace();
		}
		return psmt;
	}
	
	
	
	/*
	 *   执行SQL语句,用于查询、计数等操作
	 */
	public ResultSet executeQuery(String sql) {
		try {
			rs = stmt.executeQuery(sql);
			if(rs != null) 
				System.out.println("   ");
			else 
				System.out.println("警告：数据查询失败！！！");
		} catch(SQLException sqle) {
			sqle.printStackTrace();
		}
		return rs;
	}
	
	
	
	/*
	 *    执行SQL语句，用于删除、插入等操作
	 */
	public int executeUpdate(String sql) {
		int mark = 0;
		try {
			mark = stmt.executeUpdate(sql);
			if(mark != 0) 
				System.out.println("   ");
			else 
				System.out.println("警告：数据库更新失败！！！");
		} catch(SQLException e) {
			e.printStackTrace();
		}
		return mark;
	}
	
	
	
	/*
	 *    关闭连接
	 */
	public void close() {
		try{if(rs != null)rs.close();} catch(SQLException se){}
		try{if(stmt != null)stmt.close();}catch(SQLException se){}
		try{if(conn != null)conn.close();}catch(SQLException se){} finally { System.out.println("*"); System.out.println("");}
	}
}

