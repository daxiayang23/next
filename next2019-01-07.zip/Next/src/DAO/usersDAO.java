package DAO;

import java.sql.ResultSet;

import tool.tip;

import bean.usersBean;

public class usersDAO {
	
	
	
	/*
	 * 功能一：添加用户
	 */
	public boolean addUser(usersBean ub) {
		baseDAO db = new baseDAO();
		int mark = 0;
		try {
			String sql = 
				"insert into users (unumber,uname,upass,studentsnum) values ('"+ub.getuNumber()+"','"+ub.getuName()+"','"+ub.getuPass()+"','"+ub.getStudentsnum()+"')";
			db.getConnection();
			db.createStatement();
			mark = db.executeUpdate(sql);	
			if(mark != 0) {
				tip.showTip("用户表");
				tip.showTip("用户流水号 "+ub.getuNumber());
				tip.showTip("用户名 "+ub.getuName());
				tip.showTip("用户密码 "+ub.getuPass());
				tip.showTip("学号 "+ub.getStudentsnum());
			} else {
				System.out.println("字段插入失败！！");
			}
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			db.close();
		}
		return mark==0?false:true;
	}
	
	
	/*
	 *  功能二：更新数据库
	 */
	
	public int updateUser(String unumber, String segment, int variable, int i) {
		baseDAO db = new baseDAO();
		int mark = 0;
		try {
			String sql = "";
			if(i == 0)
				sql = "update users set uname='" + segment + "' where unumber='"+ unumber +"'";
			else if(i == 1) 
				sql = "update users set upass='" + segment + "' where unumber='"+ unumber +"'";
			else if(i == 2)
				sql = "update users set email='" + segment + "' where unumber='"+ unumber +"'";
			else if(i == 3)
				sql = "update users set address='" + segment + "' where unumber='"+ unumber +"'";
			else if(i == 4)
				sql = "update users set balance='" + variable + "' where unumber='"+ unumber +"'";
			else if(i == 5)
				sql = "update users set uhead='" + segment + "' where unumber='"+ unumber +"'";
			else if(i == 6)
				sql = "update users set ustatus='" + variable + "' where unumber='"+ unumber +"'";
			else if(i == 7)
				sql = "update users set cartsrecord='" + variable + "' where unumber='"+ unumber +"'";
			else if(i == 8)
				sql = "update users set goodsrecord='" + variable + "' where unumber='"+ unumber +"'";
			else if(i == 9)
				sql = "update users set qq='" + segment + "' where unumber='"+ unumber +"'";
			else if(i == 10)
				sql = "update users set wechat='" + segment + "' where unumber='"+ unumber +"'";
			else if(i == 11)
				sql = "update users set phone='" + segment + "' where unumber='"+ unumber +"'";
			else if(i == 12)
				sql = "update users set studentsnum='" + segment + "' where unumber='"+ unumber +"'";
			else if(i == 13)
				sql = "update users set birthday='" + segment + "' where unumber='"+ unumber +"'";
			else
				System.out.println("错误：无任何操作！！");
			db.getConnection();
			db.createStatement();
			mark = db.executeUpdate(sql);	
			if(mark != 0) {
				tip.showTip("成功更新字段");
			} else {
				tip.showTip("字段插入失败！！");
			}
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			db.close();
		}
		return mark;
	}
	
	
	/*
	 * 功能三：登入检测
	 */
	public int checkUser(String segment1, String segment2, int i) {
		baseDAO db = new baseDAO();
		int mark = 0;
		try {
			String sql = "select unumber from users where studentsnum='" + segment1 + "' and upass='" + segment2 + "'";
			if(i == 0) 
				sql = "select unumber from users where studentsnum='" + segment1 + "' and upass='" + segment2 + "'";
			if(i == 1)
				sql = "select unumber from users where uname='" + segment1 + "' and upass='" + segment2 + "'";
			db.getConnection();
			db.createStatement();
			ResultSet rs = db.executeQuery(sql);
			if(rs.next()) {
				mark = 1;
			}
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			db.close();
		}
		return mark;
	}
	public int checkUser(String segment1, String segment2, String segment3) {
		baseDAO db = new baseDAO();
		int mark = 0;
		try {
			String sql = "select unumber from users where uname='" + segment1 + "' and upass='" + segment2 + "' and studentsnum='" + segment3 + "'";
			db.getConnection();
			db.createStatement();
			ResultSet rs = db.executeQuery(sql);
			if(rs.next()) {
				mark = 1;
				tip.showTip("用户  " + segment1 + " 已登入");
			}
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			db.close();
		}
		return mark;
	}
	public int checkUser(usersBean ub, int i, int InputZero, int InputZeroo) {
		baseDAO db = new baseDAO();
		int mark = 0;
		try {
			String sql = "";
			if(i == 0)
				sql = "select uname from users where uname='"+ub.getuName()+"'";
			if(i == 1) 
				sql = "select unumber from users where studentsnum='"+ub.getStudentsnum()+"'";
			if(i == 2)
				sql = "select unumber from users where studentsnum='"+ub.getStudentsnum()+"' and upass='" + ub.getuPass()+ "'";
			db.getConnection();
			db.createStatement();
			ResultSet rs = db.executeQuery(sql);
			if(rs.next()) {
				mark = 1;
				tip.showTip("已存在用户"+ub.getuName());
			} else {
				tip.showTip("不存在用户"+ub.getuName());
			}
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			db.close();
		}
		return mark;
	}
	
	
	// 提取字段
	public usersBean takeSegment(String stu, int i) {
		baseDAO db = new baseDAO();
		usersBean ub = new usersBean();
		try {
			String sql = "";
			if(i == 0)
				sql = "select ustatus,unumber,uname from users where studentsnum='" + stu +"'";
			else
				tip.showTip("错误：无任何操作！！");
			db.getConnection();
			db.createStatement();
			ResultSet rs = db.executeQuery(sql);
			if(rs.next()) {
				if(i == 0) {
					int ustatus = rs.getInt(1);
					String unumber = rs.getString(2);
					String uname = rs.getString(3);
					ub.setuStatus(ustatus);
					ub.setuNumber(unumber);
					ub.setuName(uname);
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			db.close();
		}
		return ub;
	}
	
//	public static void main(String[] args) {
//		usersDAO ud = new usersDAO();
//		usersBean ub = new usersBean();
//		ub.setuNumber("0201812261233234");
//		ub.setuName("一片黑");
//		ub.setuPass("qwer1234");
//		ub.setEmail("qwer1234@qq.com");
//		ud.addUser(ub);
//		ud.updateUser("0201812261233234", "bottle", 0, 0);
//	}
	
}
