package DAO;

import tool.tip;
import bean.timeBean;

public class timeDAO {
	
	
	/*
	 * 功能一：添加时间
	 */
	public boolean addTime(timeBean tb) {
		baseDAO db = new baseDAO();
		int mark = 0;
		try {
			String sql = 
				"insert into time (body,ocurtime,status,number,statement) values ('"+tb.getBody()+"','"+tb.getOcurtime()+"','"+tb.getStatus()+"','"+tb.getNumber()+"','"+tb.getStatement()+"')";
			db.getConnection();
			db.createStatement();
			mark = db.executeUpdate(sql);	
			if(mark != 0) {
				tip.showTip("时间表");
				tip.showTip("添加主体 "+tb.getBody());
				tip.showTip("添加发生时间 "+tb.getOcurtime());
				tip.showTip("添加状态 "+tb.getStatus());
				tip.showTip("添加流水号 "+tb.getNumber());
				tip.showTip("添加声明"+tb.getStatement());
			} else {
				tip.showTip("字段插入失败！！");
			}
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			db.close();
		}
		return mark==0?false:true;
	}
	
	
}
