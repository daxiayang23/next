package FilterInstances;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;


public class SimpleFilter implements Filter {
	private String charSet;
	public void init(FilterConfig config) throws ServletException {
		String initParam = config.getInitParameter("ref");
		this.charSet = config.getInitParameter("charset");
		System.out.println("** 过滤器初始化， 初始化参数=" + initParam);
	}
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		request.setCharacterEncoding(this.charSet);
		System.out.println("** 执行doFilter之后的方法 **");
		chain.doFilter(request, response);
		System.out.println("** 执行doFilter之后的方法**");
	}
	public void destroy() {
		// TODO Auto-generated method stub
		
	}
}
