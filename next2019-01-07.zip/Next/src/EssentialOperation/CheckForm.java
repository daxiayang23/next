package EssentialOperation;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import tool.tool;

import bean.usersBean;

import DAO.usersDAO;

public class CheckForm extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public CheckForm() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html;charset=utf-8");
		
		PrintWriter out = response.getWriter();
		String uname = tool.convertToChinese(request.getParameter("uname"));
		String upass = request.getParameter("pass");
		String stu = request.getParameter("stu");
		String type = request.getParameter("type");

		usersDAO ud = new usersDAO();
		usersBean ub = new usersBean();

		if("checkUname".equals(type)) {
			ub.setuName(uname);
			if(ud.checkUser(ub, 0, 0, 0)==1) {
				out.print("true");
			} else {
				out.print("false");
			}
		}
		
		if("checkStu".equals(type)) {
			ub.setStudentsnum(stu);
			if(ud.checkUser(ub, 1, 0, 0)==1) {
				out.print("true");
			} else {
				out.print("false");
			}
		}
		
		if("checkPass".equals(type)) {
			ub.setStudentsnum(stu);
			ub.setuPass(upass);
			if(ud.checkUser(ub, 2, 0, 0)==1) {
				out.print("true");
			} else {
				out.print("false");
			}
		}
		
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
