package EssentialOperation;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import DAO.goodsDAO;
import bean.goodsBean;

import tool.IdentifierGenerator;
import tool.tool;

public class addGoods extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public addGoods() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		
		
		HttpSession session = request.getSession();
		String gNumber = IdentifierGenerator.StuffIdentifier();
		String title = request.getParameter("title");
		String number = request.getParameter("number");
		String price = request.getParameter("price");
		String stu = (String)session.getAttribute("stu");
		
		int n = Integer.parseInt(number); // 转换类型 n = number
		int p = Integer.parseInt(price);  // 转换类型 p = price
		
		goodsBean gb = new goodsBean();	  // 打包，商品流水号、标题、总数、价格、创建者
		gb.setgNumber(gNumber);
		gb.setgName(title);
		gb.setgSum(n);
		gb.setPrice(p);
		gb.setCreator(stu);
		
		int mark = goodsDAO.addGoods(gb);
		if(mark == 1) {
			out.print("上传成功");
		}
		
		out.flush();
		out.close();
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
