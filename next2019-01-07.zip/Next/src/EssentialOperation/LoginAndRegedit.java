package EssentialOperation;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.timeBean;
import bean.usersBean;

import DAO.timeDAO;
import DAO.usersDAO;

import tool.IdentifierGenerator;
import tool.tip;
import tool.tool;
import tool.Time;

public class LoginAndRegedit extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public LoginAndRegedit() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		PrintWriter out = response.getWriter();
		response.setContentType("text/html;charset=utf-8");
		out
				.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
		out.println("<HTML>");
		out.println("  <HEAD><TITLE>登入</TITLE></HEAD>");
		out.println("  <BODY>");
		
		//登入和注册前，先执行注销操作
		HttpSession session1 = request.getSession();
		if(session1.getAttribute("uname")!=null) {
			session1.removeAttribute("uname");
		}
		session1.invalidate();
		
		
		/*
		 * 登入
		 */
		
		HttpSession session = request.getSession();
		
		// 定义变量
		String login = request.getParameter("log");
		String regedit = request.getParameter("reg");
		
		//登入
		if(login != null) {
			String stu = request.getParameter("log-studentsnum");
			String upass = request.getParameter("upass");
			usersDAO u = new usersDAO();
			if(u.checkUser(stu, upass, 0) != 0) {
				tip.showTip("登入成功");
				out.print("true");
				session.setAttribute("stu", stu);

				//记录日志
				int body = 0;
				String ocurtime = Time.CurrentTime();
				int status = u.takeSegment(stu, 0).getuStatus();
				String number = u.takeSegment(stu, 0).getuNumber();
				String statement = "log in";
				timeBean tb = new timeBean();
				tb.setBody(body);
				tb.setOcurtime(ocurtime);
				tb.setStatus(status);
				tb.setNumber(number);
				tb.setStatement(statement);
				timeDAO td = new timeDAO();
				td.addTime(tb);
				
				String url = "home.jsp";
				RequestDispatcher rd = request.getRequestDispatcher(url);
				rd.forward(request, response);
				
			} else {
				out.print(stu + upass);
				out.print("false");
				tip.showTip("登入失败");
			}
			
		}
		
		//注册
		if(regedit != null) {
			String unumber = IdentifierGenerator.HumanIdentifier();
			String uname = tool.convertToChinese(request.getParameter("uname"));
			String upass = request.getParameter("upass");
			String stu = request.getParameter("studentsnum");
			int uStatus = 2;
			tip.showTip(unumber+uname+upass+stu+uStatus);
			usersBean ub = new usersBean();
			ub.setuNumber(unumber);
			ub.setuName(uname);
			ub.setuPass(upass);
			ub.setStudentsnum(stu);
			ub.setuStatus(uStatus);
			usersDAO u = new usersDAO();
			if(u.checkUser(stu, upass, 0) != 0) {
				tip.showTip("该同学已经注册");
				out.print("false");
			} else {
				u.addUser(ub);
				out.print("true");

				//记录日志
				int body = 0;
				String ocurtime = Time.CurrentTime();
				String statement = "reg and log in";
				timeBean tb = new timeBean();
				tb.setBody(body);
				tb.setOcurtime(ocurtime);
				tb.setStatus(uStatus);
				tb.setNumber(unumber);
				tb.setStatement(statement);
				timeDAO td = new timeDAO();
				td.addTime(tb);
			}
			session.setAttribute("stu", stu);
		}
		
		out.println("  </BODY>");
		out.println("</HTML>");
		out.flush();
		out.close();
		
		
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
