package EssentialOperation;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import tool.Time;
import tool.tip;
import DAO.timeDAO;
import DAO.usersDAO;
import bean.timeBean;
import bean.usersBean;

public class Login extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public Login() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		PrintWriter out = response.getWriter();
		response.setContentType("text/html;charset=utf-8");
		
		HttpSession session = request.getSession();
		String stu = request.getParameter("stu");
		String upass = request.getParameter("upass");
		usersDAO u = new usersDAO();
		usersBean ub = new usersBean();
		if(u.checkUser(stu, upass, 0) != 0) {
			tip.showTip("登入成功");
			session.setAttribute("stu", stu);
			// 查找学号对应的学生姓名
			ub.setStudentsnum(stu);
			ub = u.takeSegment(stu, 0);
			String uname = ub.getuName();
			tip.showTip(uname);
			out.print(uname);
			
			
			// 记录日志
			int body = 0;
			String ocurtime = Time.CurrentTime();
			int status = u.takeSegment(stu, 0).getuStatus();
			String number = u.takeSegment(stu, 0).getuNumber();
			String statement = "log in";
			timeBean tb = new timeBean();
			tb.setBody(body);
			tb.setOcurtime(ocurtime);
			tb.setStatus(status);
			tb.setNumber(number);
			tb.setStatement(statement);
			timeDAO td = new timeDAO();
			td.addTime(tb);
				
		} else {
			tip.showTip("登入失败");
		}
			
		
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
