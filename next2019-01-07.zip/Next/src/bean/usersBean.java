package bean;

public class usersBean {
	private String uNumber;			// 账户流水号
	private String uName;			// 账户名称
	private String uPass;			// 账户密码
	private int gender;				// 性别=0：保密 1：男 2：女
	private String email;			// 账户邮箱
	private String realName;		// 真实姓名
	private String address;			// 住址
	private String uHead;			// 头像
	private boolean seller;			// 是否是商家
	private double balance;			// 账户余额
	private int uStatus;			// 账户状态=0：注销 1：正常 2：待审核 3：异常
	private int cartsRecord;		// 购物车记录数
	private int goodsRecord;		// 商品记录数
	private String qq;				// qq号
	private String wechat;			// 微信号
	private String phone;			// 账户手机号
	private String studentsnum;		// 学号
	private String birthday;		// 生日
	
	public String getBirthday() {
		return birthday;
	}
	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}
	public String getuNumber() {
		return uNumber;
	}
	public void setuNumber(String uNumber) {
		this.uNumber = uNumber;
	}
	public String getuName() {
		return uName;
	}
	public void setuName(String uName) {
		this.uName = uName;
	}
	public String getuPass() {
		return uPass;
	}
	public void setuPass(String uPass) {
		this.uPass = uPass;
	}
	public int getGender() {
		return gender;
	}
	public void setGender(int gender) {
		this.gender = gender;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getRealName() {
		return realName;
	}
	public void setRealName(String realName) {
		this.realName = realName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getuHead() {
		return uHead;
	}
	public void setuHead(String uHead) {
		this.uHead = uHead;
	}
	public boolean isSeller() {
		return seller;
	}
	public void setSeller(boolean seller) {
		this.seller = seller;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public int getuStatus() {
		return uStatus;
	}
	public void setuStatus(int uStatus) {
		this.uStatus = uStatus;
	}
	public int getCartsRecord() {
		return cartsRecord;
	}
	public void setCartsRecord(int cartsRecord) {
		this.cartsRecord = cartsRecord;
	}
	public int getGoodsRecord() {
		return goodsRecord;
	}
	public void setGoodsRecord(int goodsRecord) {
		this.goodsRecord = goodsRecord;
	}
	public String getQq() {
		return qq;
	}
	public void setQq(String qq) {
		this.qq = qq;
	}
	public String getWechat() {
		return wechat;
	}
	public void setWechat(String wechat) {
		this.wechat = wechat;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getStudentsnum() {
		return studentsnum;
	}
	public void setStudentsnum(String studentsnum) {
		this.studentsnum = studentsnum;
	}
	
}
