package bean;

public class picturesBean {
	private String identifier;		// 图片流水号
	private String photo;			// 图片相对路径
	private String cidentifier;		// 从属者流水号
	private int size;				// 图片大小
	private int pstatus;			// 图片状态
	
	public int getPstatus() {
		return pstatus;
	}
	public void setPstatus(int pstatus) {
		this.pstatus = pstatus;
	}
	public String getIdentifier() {
		return identifier;
	}
	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}
	public String getPhoto() {
		return photo;
	}
	public void setPhoto(String photo) {
		this.photo = photo;
	}
	public String getCidentifier() {
		return cidentifier;
	}
	public void setCidentifier(String cidentifier) {
		this.cidentifier = cidentifier;
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	
}
