package bean;

public class cartsBean {
	private String cartNumber;		// 购物车流水号
	private String gNumber;			// 商品流水号
	private String uNumber;			// 用户流水号
	private int buy;				// 购买数量
	private int cStatus;			// 购物车状态=0：未支付 1：已支付 2：已收货
	private String buyer;			// 购买者流水号
	private int payment;			// 支付状态=0：未支付 1：已支付 2：已收货
	
	
	public String getgNumber() {
		return gNumber;
	}
	public void setgNumber(String gNumber) {
		this.gNumber = gNumber;
	}
	public String getCartNumber() {
		return cartNumber;
	}
	public void setCartNumber(String cartNumber) {
		this.cartNumber = cartNumber;
	}
	public String getuNumber() {
		return uNumber;
	}
	public void setuNumber(String uNumber) {
		this.uNumber = uNumber;
	}
	public int getBuy() {
		return buy;
	}
	public void setBuy(int buy) {
		this.buy = buy;
	}
	public int getcStatus() {
		return cStatus;
	}
	public void setcStatus(int cStatus) {
		this.cStatus = cStatus;
	}
	public String getBuyer() {
		return buyer;
	}
	public void setBuyer(String buyer) {
		this.buyer = buyer;
	}
	public int getPayment() {
		return payment;
	}
	public void setPayment(int payment) {
		this.payment = payment;
	}
	
	
}
