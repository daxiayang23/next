package bean;

public class timeBean {
	private int body;			// 事件主体=0：人 1：物  2：购物车 3：好友 4：赠送 5：类型 6：留言
	private String ocurtime;	// 发生时间
	private int status;			// 状态
	private String number;		// 流水号
	private boolean tag;		// 标记=0：未标记 1：标记
	private String statement;	// 说明
	
	
	public String getStatement() {
		return statement;
	}
	public void setStatement(String statement) {
		this.statement = statement;
	}
	public int getBody() {
		return body;
	}
	public void setBody(int body) {
		this.body = body;
	}
	public String getOcurtime() {
		return ocurtime;
	}
	public void setOcurtime(String ocurtime) {
		this.ocurtime = ocurtime;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public boolean isTag() {
		return tag;
	}
	public void setTag(boolean tag) {
		this.tag = tag;
	}
	
	
}
