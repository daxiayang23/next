package bean;

public class goodsBean {
	
	private String gNumber;		// 商品流水号
	private String gName;		// 商品名称
	private int gStatus;		// 商品状态=0：不存在 1：未成交 2：待审核 3：已成交 4：未发布
	private String creator;		// 创建者流水号
	private int gSum;			// 商品总数
	private String gPic1;		// 商品图片1
	private String gPic2;		// 商品图片2
	private int price;			// 商品价格
	private boolean gift;		// 是否当成礼物=0：否 1：是
	
	
	public String getgNumber() {
		return gNumber;
	}
	public void setgNumber(String gNumber) {
		this.gNumber = gNumber;
	}
	public String getgName() {
		return gName;
	}
	public void setgName(String gName) {
		this.gName = gName;
	}
	public int getgStatus() {
		return gStatus;
	}
	public void setgStatus(int gStatus) {
		this.gStatus = gStatus;
	}
	public String getCreator() {
		return creator;
	}
	public void setCreator(String creator) {
		this.creator = creator;
	}
	public int getgSum() {
		return gSum;
	}
	public void setgSum(int gSum) {
		this.gSum = gSum;
	}
	public String getgPic1() {
		return gPic1;
	}
	public void setgPic1(String gPic1) {
		this.gPic1 = gPic1;
	}
	public String getgPic2() {
		return gPic2;
	}
	public void setgPic2(String gPic2) {
		this.gPic2 = gPic2;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public boolean isGift() {
		return gift;
	}
	public void setGift(boolean gift) {
		this.gift = gift;
	}
	
	
	
}
