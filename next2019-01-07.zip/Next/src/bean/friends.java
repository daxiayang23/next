package bean;

public class friends {
	private String uNumber;			// 用户流水号
	private String userNumber;		// 用户流水号
	private int fStatus;			// 好友状态=0：待申请 1：好友 2：非好友
	private int close;				// 亲密度=0：好友 1：亲密好友 2：挚友
	private boolean interFollow;	// 是否相互关注=0：否 1：是
	private String reserve;			// 预留字段
	
	
	public String getuNumber() {
		return uNumber;
	}
	public void setuNumber(String uNumber) {
		this.uNumber = uNumber;
	}
	public String getUserNumber() {
		return userNumber;
	}
	public void setUserNumber(String userNumber) {
		this.userNumber = userNumber;
	}
	public int getfStatus() {
		return fStatus;
	}
	public void setfStatus(int fStatus) {
		this.fStatus = fStatus;
	}
	public int getClose() {
		return close;
	}
	public void setClose(int close) {
		this.close = close;
	}
	public boolean isInterFollow() {
		return interFollow;
	}
	public void setInterFollow(boolean interFollow) {
		this.interFollow = interFollow;
	}
	public String getReserve() {
		return reserve;
	}
	public void setReserve(String reserve) {
		this.reserve = reserve;
	}
	
	
}
