
var xmlHttp;
var flag1 = false; // 注册时的用户名
var flag2 = false; // 注册时的学号
var flag3 = false; // 登入时的学号
var flag4 = false; // 登入时的密码和学号的正确性
var flag5 = false; // 提交注册表单
var flag6 = false; // 提交登入表单
var flag7 = false; // 注册时的学号输入限制
var flag8 = false; // 检测密码长度的规范性
var flag9 = false; // 两次输入密码的一致性
var type;


function createXMLHttp() {
	if(window.XMLHttpRequest) {
		xmlHttp = new XMLHttpRequest();
	} else {
		xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
	}
}


// 注册时，检查用户名是否可用

function checkUname(uname){
	createXMLHttp();
	type = "checkUname";
	if(uname != "") {
		xmlHttp.open("POST", "CheckForm?uname="+uname+"&type="+type);
		xmlHttp.onreadystatechange = checkUnameCallBack;
		xmlHttp.send(null);
		document.getElementById("insert1").innerHTML="正在验证。。。";
	} else {
		document.getElementById("insert1").innerHTML="未输入";
	}
}

function checkUnameCallBack(){
	if(xmlHttp.readyState == 4){
		if(xmlHttp.status == 200){
			var text = xmlHttp.responseText;
			if(text!="true"){
				flag1 = true;
				document.getElementById("insert1").innerHTML="可用";
			} else {
				flag1 = false;
				document.getElementById("insert1").innerHTML="已被注册，无法使用";
			}
			checkForm();
		}
	}
}







// 注册时，检查学号是否可用

function checkStu(stu){
	createXMLHttp();
	type = "checkStu";
	var i = stu.length;
	if(i != 0) {
		if( i == 10) {
			xmlHttp.open("POST", "CheckForm?stu="+stu+"&type="+type);
			xmlHttp.onreadystatechange = checkStuCallBack;
			xmlHttp.send(null);
			document.getElementById("insert4").innerHTML="正在验证。。。";
		} else {
			document.getElementById("insert4").innerHTML="长度不匹配";
			flag2 = false;
			checkForm()
		}
	} else {
		document.getElementById("insert4").innerHTML="未输入";
		flag2 = false;
		checkForm()
	}
	
}

function checkStuCallBack(){
	if(xmlHttp.readyState == 4){
		if(xmlHttp.status == 200){
			var text = xmlHttp.responseText;
			if(text!="true"){
				flag2 = true;
				document.getElementById("insert4").innerHTML="尚未被注册";
				checkForm();
			} else {
				flag2 = false;
				document.getElementById("insert4").innerHTML="已被注册";
				checkForm()
			}
		}
	}
}







//登入时，检查学号是否可用

function checkStud(stu){
	createXMLHttp();
	type = "checkStu";
	if(stu != "") {
		xmlHttp.open("POST", "CheckForm?stu="+stu+"&type="+type);
		xmlHttp.onreadystatechange = checkStudCallBack;
		xmlHttp.send(null);
		document.getElementById("insert5").innerHTML="正在验证。。。";
	} else {
		document.getElementById("insert5").innerHTML="未输入";
		flag3 = false;
		checkFormm();
	}
	
}

function checkStudCallBack(){
	if(xmlHttp.readyState == 4){
		if(xmlHttp.status == 200){
			var text = xmlHttp.responseText;
			if(text!="true"){
				flag3 = false;
				document.getElementById("insert5").innerHTML="不存在";
				checkFormm();
			} else {
				flag3 = true;
				document.getElementById("insert5").innerHTML="对的";
				checkFormm();
			}
		}
	}
}


//登入时，检查密码是否正确

function checkPass(pass){
	createXMLHttp();
	type = "checkPass";
	var stu = document.forms["login"]["studentsnum"].value;
	if(stu != "") {
		xmlHttp.open("POST", "CheckForm?stu="+stu+"&pass="+pass+"&type="+type);
		xmlHttp.onreadystatechange = checkPassCallBack;
		xmlHttp.send(null);
		document.getElementById("insert6").innerHTML="正在验证。。。";
	} else {
		document.getElementById("insert6").innerHTML="未输入";
		flag4 = false;
		checkFormm();
	}
}

function checkPassCallBack(){
	if(xmlHttp.readyState == 4){
		if(xmlHttp.status == 200){
			var text = xmlHttp.responseText;
			if(text!="true"){
				flag4 = false;
				document.getElementById("insert6").innerHTML="密码错误";
				checkFormm();
			} else {
				flag4 = true;
				document.getElementById("insert6").innerHTML="对的";
				checkFormm();
			}
		}
	}
}




// 提交注册表单

function regForm() {
	showLoading();
	var uname = document.forms["regedit"]["uname"].value;
	var upass = document.forms["regedit"]["upass"].value;
	var stu = document.forms["regedit"]["studentsnum"].value;
	var str = "Regedit?stu="+stu+"&upass="+upass+"&uname="+uname;
	xmlHttp.open("POST", str);
	xmlHttp.onreadystatechange = regFormCallBack;
	xmlHttp.send(null);
	setTimeout("$('#site-index-regedit-loading').fadeOut(100)", 1000);			// 加载页面淡出
	setTimeout("$('#site-index-loading-beneath-text-done').css({'display':'none'})", 1100);
	setTimeout("$('#site-index-loading-beneath-text-undone').css({'display':'none'})", 1100);
}

function regFormCallBack(){
	if(xmlHttp.readyState == 4){
		if(xmlHttp.status == 200){
			var text = xmlHttp.responseText;
			if(text!="true"){
				flag5 = false;
				$("#site-index-loading-beneath-text-undone").fadeIn(100);// 注册失败字样显示
				setTimeout(1000);
			} else {
				flag5 = true;
				$("#site-index-loading-beneath-text-done").fadeIn(100);	// 注册成功字样显示
				setTimeout("$('#site-index-ul-regedit').fadeOut(100)",1001);// 注册表单淡出
//				$('#site-index-ul-regedit').fadeOut(100);			
				setTimeout("$('#site-index-ul-login').fadeIn(100)",1200);	// 登入表单显示
				
			}
		}
	}
}


// 提交登入表单

function logForm() {
	var stu = document.forms["login"]["log-studentsnum"].value;
	var upass = document.forms["login"]["upass"].value;
	var url = "NewLogin";
	$.post(url,
			{
			stu:stu,
			upass:upass
			},
			function(data, status, xhr) {
				$("#site-index-login").fadeOut(100);   // 登入表单的淡出
				setTimeout("$('#site-index-log-in-tip').fadeIn(100)",150);	  // 登入成功字样提示
				setTimeout("$('#site-index').fadeOut(100)",1333); // 延迟300ms，整体index的淡出
				$("#site-head-inneruname").text(data);
			});
}

//function logForm() {
//	var stu = document.forms["login"]["log-studentsnum"].value;
//	var upass = document.forms["login"]["upass"].value;
//	var str = "Login?stu="+stu+"&upass="+upass;
//	xmlHttp.open("POST", str);
//	xmlHttp.onreadystatechange = logFormCallBack;
//	xmlHttp.send(null);
//}
//
//function logFormCallBack(){
//	if(xmlHttp.readyState == 4){
//		if(xmlHttp.status == 200){
//			var text = xmlHttp.responseText;
//			if(text!=""){
//				flag6 = true;
//				$("#site-index-login").fadeOut(100);   // 登入表单的淡出
//				setTimeout("$('#site-index-log-in-tip').fadeIn(100)",150);	  // 登入成功字样提示
//				setTimeout("$('#site-index').fadeOut(100)",1333); // 延迟300ms，整体index的淡出
////				$("#site-head-inneruname").load("/Login");			 
//				document.getElementById("site-head-inneruname").innerHTML = text;// 在home.jsp中显示用户昵称
////				document.getElementById("site-index-log-span").innerHTML = text;
//			} else {
//				flag6 = false;
//			}
//		}
//	}
//}


/*
 * 以下是index.jsp的输入限制
 */



// 注册时，输入中，学号的输入限制，只能输入数字
function RegStuInputLimited(str) {
	var i = str.length;
	var j;
	var num;
	

	if( i >= 10) {
		flag7 = false;
	} else if( i >= 2 ) {
		j = str.substr(-1);
		num = Number(j);
		if(isNaN(num)) {
			document.getElementById("insert4").innerHTML="只能含有数字";
			flag7 = false;
			checkForm()
		} else {
			flag7 = true;
			checkForm();
		}
	} else if(i < 2) {
		num = Number(str);
		if(isNaN(num)){
			document.getElementById("insert4").innerHTML="只能含有数字";
			flag7 = false;
			checkForm()
		} else {
			flag7 = true;
			checkForm();
		}
	} 
	checkStu(str)
}

// 检验密码长度
function RegPassInputLimited(str) {
	var i = str.length;
	if(i == 0) {
		flag8 = false;
		document.getElementById("insert2").innerHTML="未输入";
		checkForm();
		return;
	}
	if(i > 6) {
		document.getElementById("insert2").innerHTML="可用";
		flag8 = true;
		checkForm();
	} else {
		flag8 = false;
		document.getElementById("insert2").innerHTML="密码过短";
		checkForm();
	}
	
	
}

// 比较两次输入密码一致性
function passCompare(pass) {
	var ring = document.forms["regedit"]["upass"].value;
	
	if(ring != pass) {
		document.getElementById("insert3").innerHTML="两次输入不一致";
		flag9 = false;
		checkForm()
	} else {
		document.getElementById("insert3").innerHTML="通过";
		flag9 = true;
		checkForm();
	}
}


// 注册时，验证表单正确性，最终的提交按钮高亮并可以被点击，触发事件
function checkForm(){
	if(flag1 && flag2 && flag8 && flag9) {
		$("#site-index-reg-button").animate({opacity:'1'});
		$("#site-index-reg-button").css({"pointer-events":"auto","cursor":"pointer"});
	} else {
		$("#site-index-reg-button").animate({opacity:'0.4'});
		$("#site-index-reg-button").css({"pointer-events":"none","cursor":"none"});
	}
}

// 登入时，验证表单里的学号和密码的正确性，触发事件：按钮高亮且可以被点击
function checkFormm(){
	if(flag3 && flag4) {
		$("#site-index-log-button").animate({opacity:'1'});
		$("#site-index-log-button").css({"pointer-events":"auto","cursor":"pointer"});
	} else {
		$("#site-index-log-button").animate({opacity:'0.4'});
		$("#site-index-log-button").css({"pointer-events":"none","cursor":"none"});
	}
}


// 超链接，stage中间显示注册表单或者登入表单
$(document).ready(function(){
	  $("#site-index-reg-span-haveacc").click(function(){
	    $("#site-index-ul-regedit").fadeOut(100);
	    setTimeout("$('#site-index-ul-login').fadeIn(100)",110);
	  });
	  
	  $("#site-index-log-span-noacc").click(function(){
		$("#site-index-ul-login").fadeOut(100);
		setTimeout("$('#site-index-ul-regedit').fadeIn(100)",110);
	  });
});

// 显示Loading界面，并限制对表单的输入
function showLoading() {
	$("#site-index-regedit-loading").fadeIn(100);
}


