
/*
 *  商品发布按钮触发事件，移动按钮，并改变事件形式，toggle关闭发布表单或打开发布表单
 */

$(document).ready(function(){
	  $("#site-head-ReleaseGoods-plus").click(function(){
	    $("#site-home-ReleaseGood").fadeToggle(100);
	    var tip = $("#site-head-ReleaseGoods-plus-tag").text();
	    if(tip == "发布") {
	    	$("#site-head-ReleaseGoods-plus").animate({"top":"9px", "right":"9px"});
	    	$("#site-head-ReleaseGoods-plus-tag").text("关闭");
	    }
	    if(tip == "关闭") {
	    	$("#site-head-ReleaseGoods-plus").animate({"top":"750px", "right":"186px"});
	    	$("#site-head-ReleaseGoods-plus-tag").text("发布");
	    }	
	  });
});




/*
 *  提交商品的基本信息，包括价格、数量、标题
 */

var title = "";
var number = "";
var price = "";

function activeReleaseButton() { // activeReleaseButton()事件，用于各个input判断是否有输入，若空值则无法让表单的button触发上传数据库的事件
	
	title = $("#site-home-ReleaseGood-name-textarea").val();
	number = $("#site-home-ReleaseGood-number").val();
	price = $("#site-home-ReleaseGood-price").val();
	
	if(title!=""&&number!=""&&price!="") {
		$("#site-home-ReleaseGood-button").animate({opacity:"1"});
		$("#site-home-ReleaseGood-button").css({"pointer-events":"auto","cursor":"pointer"});
	} else {
		$("#site-home-ReleaseGood-button").css({"pointer-events":"none","cursor":"none"});
		$("#site-home-ReleaseGood-button").animate({opacity:"0.4"});
	}
}


function submitGoods() { // submitGoods()事件，用于上传商品的基本信息到数据库
	var url = "addGoods";
	$.post(url,
			{
			title:title,
			number:number,
			price:price
			},
			function(data, status, xhr){
				$("#site-home-ReleaseGood-button").css({"pointer-events":"none","cursor":"none"});
				$("#site-home-ReleaseGood-button").animate({opacity:"0.4"});
				$("#site-home-ReleaseGood-name-textarea").val("");
				$("#site-home-ReleaseGood-number").val("");
				$("#site-home-ReleaseGood-price").val("");
			})
}








/*
 * 	列出所有商品，直接通过js插入html代码
 */


